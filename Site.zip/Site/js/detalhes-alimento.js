let idSelecionado = null;

const opcoesCategoria = CATEGORIAS.map((c) => `<option>${c}</option>`).join("");
const opcoesUnidade = UNIDADES.map((u) => `<option>${u}</option>`).join("");

document.body.insertAdjacentHTML(
  "beforeend",
  `<div class="modal" id="modal-alimento" role="dialog" aria-modal="true" aria-labelledby="modal-titulo">
  <div class="modal-caixa">
    <div class="modal-topo"><h2 id="modal-titulo"></h2><button type="button" class="acao" id="fechar-modal" aria-label="Fechar"><i class="bi bi-x-lg"></i></button></div>
    <div id="modo-detalhes">
      <div class="detalhes">
        <div><span>Quantidade</span><b id="det-quantidade"></b></div>
        <div><span>Categoria</span><b id="det-categoria"></b></div>
        <div><span>Validade</span><b id="det-validade"></b></div>
        <div><span>Valor estimado</span><b id="det-valor"></b></div>
        <div><span>Status</span><div id="det-status"></div></div>
        <div class="inteira"><span>Observações</span><b id="det-observacoes"></b></div>
      </div>
      <div class="acoes"><button type="button" class="botao perigo" id="excluir-alimento"><i class="bi bi-trash"></i> Excluir</button><button type="button" class="botao" id="editar-alimento"><i class="bi bi-pencil"></i> Editar</button></div>
    </div>
    <form class="formulario" id="formulario-editar" hidden>
      <div><label for="editar-nome">Nome</label><input class="campo" id="editar-nome" required></div>
      <div><label for="editar-categoria">Categoria</label><select class="campo" id="editar-categoria">${opcoesCategoria}</select></div>
      <div><label for="editar-quantidade">Quantidade</label><input class="campo" id="editar-quantidade" type="number" min="0.01" step="any" required></div>
      <div><label for="editar-unidade">Unidade</label><select class="campo" id="editar-unidade">${opcoesUnidade}</select></div>
      <div><label for="editar-validade">Data de validade</label><input class="campo" id="editar-validade" type="date" required></div>
      <div><label for="editar-valor">Valor estimado (R$)</label><input class="campo" id="editar-valor" inputmode="decimal" required></div>
      <div style="grid-column:1/-1"><label for="editar-observacoes">Observações</label><textarea class="campo" id="editar-observacoes" rows="3" maxlength="200"></textarea></div>
      <div class="acoes" style="grid-column:1/-1"><button type="button" class="botao contorno" id="cancelar-edicao">Cancelar</button><button type="submit" class="botao">Salvar</button></div>
    </form>
  </div>
</div>`,
);

const modal = document.getElementById("modal-alimento");
const formularioEditar = document.getElementById("formulario-editar");
const modoDetalhes = document.getElementById("modo-detalhes");

function buscarAlimento(id) {
  return obterAlimentos().find((a) => a.id === id);
}
function avisarMudanca() {
  document.dispatchEvent(new Event("alimentos-alterados"));
}

function abrirDetalhes(id) {
  const a = buscarAlimento(id);
  if (!a) return;
  idSelecionado = id;
  const s = statusAlimento(a.validade);
  document.getElementById("modal-titulo").textContent = a.nome;
  document.getElementById("det-quantidade").textContent = `${a.quantidade} ${a.unidade}`;
  document.getElementById("det-categoria").textContent = a.categoria;
  document.getElementById("det-validade").textContent = formatarData(a.validade);
  document.getElementById("det-valor").textContent = formatarMoeda(a.valor);
  document.getElementById("det-status").innerHTML = `<span class="etiqueta ${s.classe}">${s.texto}</span>`;
  document.getElementById("det-observacoes").textContent = a.observacoes || "Nenhuma observação cadastrada.";
  modoDetalhes.hidden = false;
  formularioEditar.hidden = true;
  modal.classList.add("aberto");
}

function fecharModal() {
  modal.classList.remove("aberto");
}

function iniciarEdicao() {
  const a = buscarAlimento(idSelecionado);
  if (!a) return;
  document.getElementById("editar-nome").value = a.nome;
  document.getElementById("editar-categoria").value = a.categoria;
  document.getElementById("editar-quantidade").value = a.quantidade;
  document.getElementById("editar-unidade").value = a.unidade;
  document.getElementById("editar-validade").value = a.validade;
  document.getElementById("editar-valor").value = String(a.valor ?? "").replace(".", ",");
  document.getElementById("editar-observacoes").value = a.observacoes || "";
  document.getElementById("modal-titulo").textContent = "Editar alimento";
  modoDetalhes.hidden = true;
  formularioEditar.hidden = false;
}

function salvarEdicao(evento) {
  evento.preventDefault();
  const valor = Number(document.getElementById("editar-valor").value.replace(",", "."));
  if (isNaN(valor) || valor < 0) {
    alert("Digite um valor válido. Exemplo: 5,90");
    return;
  }
  const alimentos = obterAlimentos();
  const indice = alimentos.findIndex((a) => a.id === idSelecionado);
  if (indice === -1) return;
  alimentos[indice] = {
    ...alimentos[indice],
    nome: document.getElementById("editar-nome").value.trim(),
    categoria: document.getElementById("editar-categoria").value,
    quantidade: Number(document.getElementById("editar-quantidade").value),
    unidade: document.getElementById("editar-unidade").value,
    validade: document.getElementById("editar-validade").value,
    valor: valor,
    observacoes: document.getElementById("editar-observacoes").value.trim(),
  };
  salvarAlimentos(alimentos);
  fecharModal();
  avisarMudanca();
}

function excluirAlimento(id) {
  if (!confirm("Deseja realmente excluir este alimento?")) return;
  salvarAlimentos(obterAlimentos().filter((a) => a.id !== id));
  fecharModal();
  avisarMudanca();
}

function resolverAlimento(id) {
  const a = buscarAlimento(id);
  if (!a || !confirm("Marcar este alimento como resolvido? Ele sai da lista de alimentos.")) return;
  const resolvidos = lerLista(CHAVES.resolvidos);
  resolvidos.push({ ...a, resolvidoEm: hojeISO() });
  localStorage.setItem(CHAVES.resolvidos, JSON.stringify(resolvidos));
  salvarAlimentos(obterAlimentos().filter((x) => x.id !== id));
  avisarMudanca();
}

document.addEventListener("click", function (evento) {
  const item = evento.target.closest("[data-id]");
  if (!item) return;
  const id = Number(item.dataset.id);
  const botao = evento.target.closest("[data-acao]");
  const acao = botao ? botao.dataset.acao : "ver";
  if (acao === "ver") abrirDetalhes(id);
  if (acao === "editar") {
    abrirDetalhes(id);
    iniciarEdicao();
  }
  if (acao === "excluir") excluirAlimento(id);
  if (acao === "resolver") resolverAlimento(id);
});

document.getElementById("fechar-modal").addEventListener("click", fecharModal);
document.getElementById("editar-alimento").addEventListener("click", iniciarEdicao);
document.getElementById("excluir-alimento").addEventListener("click", () => excluirAlimento(idSelecionado));
document.getElementById("cancelar-edicao").addEventListener("click", () => abrirDetalhes(idSelecionado));
formularioEditar.addEventListener("submit", salvarEdicao);
modal.addEventListener("click", (evento) => {
  if (evento.target === modal) fecharModal();
});
document.addEventListener("keydown", (evento) => {
  if (evento.key === "Escape") fecharModal();
});

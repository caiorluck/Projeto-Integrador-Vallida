const CHAVES = {
  alimentos: "vallida_alimentos",
  resolvidos: "vallida_resolvidos",
  dias: "vallida_dias_alerta",
  nome: "vallida_nome",
  email: "vallida_email",
  logado: "vallida_logado",
  preferencias: "vallida_preferencias",
};
const CATEGORIAS = [
  "Frutas",
  "Verduras",
  "Legumes",
  "Laticínios",
  "Carnes",
  "Padaria",
  "Grãos e cereais",
  "Outros",
];
const UNIDADES = ["un", "kg", "g", "L", "mL"];

if (localStorage.getItem(CHAVES.logado) !== "sim") {
  window.location.href = "login.html";
}

function lerLista(chave) {
  return JSON.parse(localStorage.getItem(chave) || "[]");
}
function obterAlimentos() {
  return lerLista(CHAVES.alimentos);
}
function salvarAlimentos(alimentos) {
  localStorage.setItem(CHAVES.alimentos, JSON.stringify(alimentos));
}

function limiteDias() {
  return Number(localStorage.getItem(CHAVES.dias) || 5);
}

function hojeISO() {
  return new Date().toLocaleDateString("sv-SE");
}

function diasAteValidade(dataValidade) {
  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0);
  const validade = new Date(dataValidade + "T00:00:00");
  return Math.ceil((validade - hoje) / 86400000);
}

function statusAlimento(dataValidade) {
  const dias = diasAteValidade(dataValidade);
  if (dias < 0) return { tipo: "vencido", texto: "Vencido", classe: "vermelho" };
  if (dias <= limiteDias()) return { tipo: "breve", texto: "Vencendo em breve", classe: "amarelo" };
  return { tipo: "ok", texto: "Dentro do prazo", classe: "verde" };
}

function textoDias(dias) {
  if (dias < 0) return `Vencido há ${Math.abs(dias)} dia(s)`;
  if (dias === 0) return "Vence hoje";
  return `Vence em ${dias} dia(s)`;
}
function formatarData(data) {
  if (!data) return "-";
  return new Date(data + "T00:00:00").toLocaleDateString("pt-BR");
}
function formatarMoeda(valor) {
  return Number(valor || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function escaparHtml(texto) {
  const div = document.createElement("div");
  div.textContent = texto == null ? "" : String(texto);
  return div.innerHTML;
}

function avisar(elemento, tipo, texto) {
  elemento.className = "mensagem " + tipo;
  elemento.textContent = texto;
}

function linhaAlerta(a) {
  const s = statusAlimento(a.validade);
  const dias = diasAteValidade(a.validade);
  return `<div class="alerta-linha" data-id="${a.id}"><span class="ponto ${s.classe}"></span><div><b>${escaparHtml(a.nome)}</b><small>${escaparHtml(a.categoria)}</small></div><small>${textoDias(dias)}</small><span class="etiqueta ${s.classe}">${s.texto}</span></div>`;
}

document.addEventListener("DOMContentLoaded", function () {
  const nome = localStorage.getItem(CHAVES.nome) || "Usuário";
  document.querySelectorAll("[data-nome-usuario]").forEach((e) => (e.textContent = nome));
  document.querySelectorAll("[data-hoje]").forEach((e) => {
    e.textContent = new Date().toLocaleDateString("pt-BR", {
      day: "numeric",
      month: "long",
      year: "numeric",
    });
  });

  const preferencias = JSON.parse(localStorage.getItem(CHAVES.preferencias) || "{}");
  if (preferencias.animacoes === false) document.body.classList.add("sem-animacoes");

  const usuario = document.querySelector(".usuario");
  const menu = usuario && usuario.querySelector(".menu-usuario");
  if (usuario && menu) {
    usuario.addEventListener("click", () => menu.classList.toggle("aberto"));
    document.addEventListener("click", (evento) => {
      if (!usuario.contains(evento.target)) menu.classList.remove("aberto");
    });
  }

  document.querySelectorAll("[data-sair]").forEach((link) => {
    link.addEventListener("click", () => localStorage.removeItem(CHAVES.logado));
  });
});

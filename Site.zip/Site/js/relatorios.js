
const soma = (lista) => lista.reduce((total, a) => total + Number(a.valor || 0), 0);
const CORES = ["#14532d", "#1f7a3f", "#4ade80", "#86efac", "#bbf7d0", "#9ca3af", "#65a30d", "#0d3b26"];

function desenharRosca(elemento, partes, total) {
  const raio = 45;
  const volta = 2 * Math.PI * raio;
  let deslocamento = 0;
  const arcos = partes
    .filter((p) => p.valor > 0)
    .map((p) => {
      const tamanho = (volta * p.valor) / total;
      const arco = `<circle cx="60" cy="60" r="${raio}" fill="none" stroke="${p.cor}" stroke-width="18" stroke-dasharray="${tamanho} ${volta - tamanho}" stroke-dashoffset="${-deslocamento}" transform="rotate(-90 60 60)"/>`;
      deslocamento += tamanho;
      return arco;
    })
    .join("");
  const legenda = partes
    .map((p) => `<li><i style="background:${p.cor}"></i>${escaparHtml(p.nome)} <b>${p.valor}</b></li>`)
    .join("");
  elemento.className = "rosca-area";
  elemento.innerHTML = `<svg viewBox="0 0 120 120" width="130" height="130" role="img"><circle cx="60" cy="60" r="${raio}" fill="none" stroke="#e3ece1" stroke-width="18"/>${arcos}<text x="60" y="62" text-anchor="middle" font-size="22" font-weight="600" fill="currentColor">${total}</text><text x="60" y="76" text-anchor="middle" font-size="9" fill="#64786b">alimentos</text></svg><ul class="legenda">${legenda}</ul>`;
}

function desenhar() {
  const alimentos = obterAlimentos();
  const resolvidos = lerLista(CHAVES.resolvidos);
  const doTipo = (tipo) => alimentos.filter((a) => statusAlimento(a.validade).tipo === tipo);
  const texto = (id, valor) => (document.getElementById(id).textContent = valor);

  texto("rel-evitado", formatarMoeda(soma(resolvidos)));
  texto("rel-economia", formatarMoeda(soma(doTipo("breve"))))
  texto("rel-total", alimentos.length);
  texto("rel-vencidos", doTipo("vencido").length);

  const roscas = document.querySelectorAll(".rosca, .rosca-area");
  if (alimentos.length) {
    const categorias = CATEGORIAS.map((c, i) => ({
      nome: c,
      valor: alimentos.filter((a) => a.categoria === c).length,
      cor: CORES[i],
    }));
    desenharRosca(roscas[0], categorias, alimentos.length);
    desenharRosca(
      roscas[1],
      [
        { nome: "Dentro do prazo", valor: doTipo("ok").length, cor: "#1f7a3f" },
        { nome: "Vencendo em breve", valor: doTipo("breve").length, cor: "#e0a01b" },
        { nome: "Vencidos", valor: doTipo("vencido").length, cor: "#c4122f" },
      ],
      alimentos.length,
    );
  }

  const melhores = [...resolvidos].sort((a, b) => b.valor - a.valor).slice(0, 5);
  if (melhores.length) {
    document.getElementById("tabela-economia").innerHTML = melhores
      .map(
        (a) =>
          `<tr><td>${escaparHtml(a.nome)}</td><td>${escaparHtml(a.categoria)}</td><td>${a.quantidade} ${escaparHtml(a.unidade)}</td><td>${formatarMoeda(a.valor)}</td></tr>`,
      )
      .join("");
  }

  const risco = alimentos
    .filter((a) => diasAteValidade(a.validade) <= limiteDias())
    .sort((a, b) => a.validade.localeCompare(b.validade))
    .slice(0, 5);
  if (risco.length) document.getElementById("top-risco").innerHTML = risco.map(linhaAlerta).join("");
}

document.addEventListener("alimentos-alterados", desenhar);
desenhar();

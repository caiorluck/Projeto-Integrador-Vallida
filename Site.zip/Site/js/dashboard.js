const limite = limiteDias();
const soma = (lista) => lista.reduce((total, a) => total + Number(a.valor || 0), 0);

function desenhar() {
  const todos = obterAlimentos();
  const breves = todos.filter((a) => statusAlimento(a.validade).tipo === "breve");
  const vencidos = todos.filter((a) => statusAlimento(a.validade).tipo === "vencido");
  const texto = (id, valor) => (document.getElementById(id).textContent = valor);

  texto("total", todos.length);
  texto("vencendo", breves.length);
  texto("vencidos", vencidos.length);
  texto("economia", formatarMoeda(soma(breves)));
  texto("texto-limite", limite);

  const alertas = [...breves, ...vencidos].sort((a, b) => a.validade.localeCompare(b.validade)).slice(0, 4);
  if (alertas.length)
    document.getElementById("alertas-recentes").innerHTML = alertas.map(linhaAlerta).join("");

  const seteDias = 7 * 86400000;
  texto("semana-cadastrados", todos.filter((a) => a.id >= Date.now() - seteDias).length);
  const proximos = todos.filter((a) => diasAteValidade(a.validade) >= 0 && diasAteValidade(a.validade) <= 7);
  texto("semana-vencendo", proximos.length);
  texto("semana-vencidos", vencidos.filter((a) => diasAteValidade(a.validade) >= -7).length);
  texto("semana-economia", formatarMoeda(soma(proximos)));
}

document.addEventListener("alimentos-alterados", desenhar);
desenhar();

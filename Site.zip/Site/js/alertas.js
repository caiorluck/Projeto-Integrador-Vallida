let tipoAtual = "todos"; 
let prioridadeAtual = "todas"; 

const corpo = document.getElementById("tabela-alertas");
const busca = document.getElementById("busca");
const filtroCategoria = document.getElementById("filtro-categoria");
const dataInicio = document.getElementById("data-inicio");
const dataFim = document.getElementById("data-fim");

function prioridade(dias) {
  if (dias <= 0) return { chave: "alta", texto: "Alta", classe: "vermelho" };
  if (dias <= 3) return { chave: "media", texto: "Média", classe: "amarelo" };
  return { chave: "baixa", texto: "Baixa", classe: "verde" };
}

function todosAlertas() {
  return obterAlimentos().filter((a) => diasAteValidade(a.validade) <= limiteDias());
}

function listaFiltrada() {
  const texto = busca.value.trim().toLowerCase();
  return todosAlertas()
    .filter((a) => {
      const dias = diasAteValidade(a.validade);
      return (
        (tipoAtual === "todos" || statusAlimento(a.validade).tipo === tipoAtual) &&
        (prioridadeAtual === "todas" || prioridade(dias).chave === prioridadeAtual) &&
        a.nome.toLowerCase().includes(texto) &&
        (filtroCategoria.selectedIndex === 0 || a.categoria === filtroCategoria.value) &&
        (!dataInicio.value || a.validade >= dataInicio.value) &&
        (!dataFim.value || a.validade <= dataFim.value)
      );
    })
    .sort((a, b) => a.validade.localeCompare(b.validade));
}

function desenhar() {
  const alertas = todosAlertas();
  const vencidos = alertas.filter((a) => diasAteValidade(a.validade) < 0).length;
  const resolvidosHoje = lerLista(CHAVES.resolvidos).filter((a) => a.resolvidoEm === hojeISO()).length;
  document.getElementById("vencidos").textContent = vencidos;
  document.getElementById("vencendo").textContent = alertas.length - vencidos;
  document.getElementById("total").textContent = alertas.length;
  document.getElementById("resolvidos").textContent = resolvidosHoje;

  document
    .querySelectorAll("[data-tipo]")
    .forEach((e) => e.classList.toggle("ativo", e.dataset.tipo === tipoAtual));
  document
    .querySelectorAll("[data-prioridade]")
    .forEach((e) => e.classList.toggle("ativo", e.dataset.prioridade === prioridadeAtual));

  const lista = listaFiltrada();
  corpo.innerHTML = lista.length
    ? lista
        .map((a) => {
          const dias = diasAteValidade(a.validade);
          const p = prioridade(dias);
          return `<tr data-id="${a.id}"><td><b>${escaparHtml(a.nome)}</b><br><small>${a.quantidade} ${escaparHtml(a.unidade)}</small></td><td>${escaparHtml(a.categoria)}</td><td>${formatarData(a.validade)}<br><small>${textoDias(dias)}</small></td><td>${dias < 0 ? "-" : dias}</td><td><span class="etiqueta ${p.classe}">${p.texto}</span></td><td><button class="botao contorno pequeno" data-acao="ver">Ver</button> <button class="botao pequeno" data-acao="resolver">Resolver</button></td></tr>`;
        })
        .join("")
    : `<tr><td colspan="6" class="vazio">Nenhum alerta por enquanto.</td></tr>`;
  document.getElementById("resumo-alertas").textContent =
    `Mostrando ${lista.length} de ${alertas.length} alertas`;
}

document.querySelectorAll("[data-tipo]").forEach((e) =>
  e.addEventListener("click", function (evento) {
    evento.preventDefault();
    tipoAtual = e.dataset.tipo;
    desenhar();
  }),
);
document.querySelectorAll("[data-prioridade]").forEach((e) =>
  e.addEventListener("click", function () {
    prioridadeAtual = e.dataset.prioridade;
    desenhar();
  }),
);
[busca, filtroCategoria, dataInicio, dataFim].forEach((campo) => {
  campo.addEventListener(campo === busca ? "input" : "change", desenhar);
});
document.getElementById("limpar-filtros").addEventListener("click", function (evento) {
  evento.preventDefault();
  tipoAtual = "todos";
  prioridadeAtual = "todas";
  busca.value = "";
  filtroCategoria.selectedIndex = 0;
  dataInicio.value = "";
  dataFim.value = "";
  desenhar();
});
document.addEventListener("alimentos-alterados", desenhar);
desenhar();

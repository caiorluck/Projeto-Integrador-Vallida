// cadastro-alimentos.js: página "Cadastro de Alimento"
const formulario = document.getElementById("formulario-alimento");
const mensagem = document.getElementById("mensagem");
const observacoes = document.getElementById("observacoes");
const contador = document.getElementById("contador");

observacoes.addEventListener("input", function () {
  contador.textContent = observacoes.value.length + "/200";
});

formulario.addEventListener("submit", function (evento) {
  evento.preventDefault();

  // Aceita "5,90" ou "5.90"
  const valor = Number(document.getElementById("valor").value.replace(",", "."));
  if (isNaN(valor) || valor < 0) {
    avisar(mensagem, "erro", "Digite um valor válido. Exemplo: 5,90");
    return;
  }

  const alimentos = obterAlimentos();
  alimentos.push({
    id: Date.now(),
    nome: document.getElementById("nome").value.trim(),
    categoria: document.getElementById("categoria").value,
    quantidade: Number(document.getElementById("quantidade").value),
    unidade: document.getElementById("unidade").value,
    validade: document.getElementById("validade").value,
    valor: valor,
    observacoes: observacoes.value.trim(),
  });
  salvarAlimentos(alimentos);

  formulario.reset();
  contador.textContent = "0/200";
  avisar(mensagem, "sucesso", "Alimento cadastrado com sucesso!");
});

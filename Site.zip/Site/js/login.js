document.querySelector(".cartao-login").addEventListener("submit", function (evento) {
  evento.preventDefault();
  const usuario = document.getElementById("usuario").value.trim();
  localStorage.setItem("vallida_logado", "sim");

  if (!localStorage.getItem("vallida_nome")) localStorage.setItem("vallida_nome", usuario);
  window.location.href = "index.html";
});

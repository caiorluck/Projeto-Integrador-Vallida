document.querySelector(".cartao-login").addEventListener("submit", function (evento) {
  evento.preventDefault();

  const usuario = document.getElementById("usuario").value.trim();
  localStorage.setItem("vallida_logado", "sim");

  const nomeSalvo = localStorage.getItem("vallida_nome");
  if (nomeSalvo === null || nomeSalvo === "") {
    localStorage.setItem("vallida_nome", usuario);
  }

  window.location.href = "index.html";
});

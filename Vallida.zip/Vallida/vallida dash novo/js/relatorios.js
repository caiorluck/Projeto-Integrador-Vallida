const grupos = document.querySelectorAll(".grupo-cards");
const titulos = ["Visão Geral", "Risco e Economia"];
let indiceAtual = 0;

function trocarGrupo(novoIndice) {
  if (novoIndice < 0) novoIndice = grupos.length - 1;
  if (novoIndice >= grupos.length) novoIndice = 0;

  indiceAtual = novoIndice;

  for (let i = 0; i < grupos.length; i++) {
    grupos[i].hidden = i !== indiceAtual;
  }

  mostrarTexto("titulo-slide", titulos[indiceAtual]);
}

document.getElementById("btn-anterior").addEventListener("click", function () {
  trocarGrupo(indiceAtual - 1);
});

document.getElementById("btn-proximo").addEventListener("click", function () {
  trocarGrupo(indiceAtual + 1);
});

function preencherLista(id, itens, vazioTexto) {
  const caixa = document.getElementById(id);
  caixa.textContent = "";

  if (itens.length === 0) {
    caixa.className = "vazio";
    caixa.textContent = vazioTexto;
    return;
  }

  caixa.className = "";
  const ul = document.createElement("ul");
  ul.className = "lista-simples";

  for (const item of itens) {
    const li = document.createElement("li");
    li.innerHTML = "<span>" + item.esquerda + "</span><b>" + item.direita + "</b>";
    ul.appendChild(li);
  }

  caixa.appendChild(ul);
}

function atualizarRelatorios() {
  const alimentos = obterAlimentos();
  const breves = [];
  const vencidos = [];
  let ok = 0;
  const porCategoria = {};

  for (const item of alimentos) {
    const tipo = statusAlimento(item.validade).tipo;
    if (tipo === "ok") ok++;
    if (tipo === "breve") breves.push(item);
    if (tipo === "vencido") vencidos.push(item);

    porCategoria[item.categoria] = (porCategoria[item.categoria] || 0) + 1;
  }

  mostrarTexto("rel-total", alimentos.length);
  mostrarTexto("rel-ok", ok);
  mostrarTexto("rel-valor-total", formatarMoeda(somarValores(alimentos)));
  mostrarTexto("rel-breve", breves.length);
  mostrarTexto("rel-economia", formatarMoeda(somarValores(breves)));
  mostrarTexto("rel-vencidos", vencidos.length);

  const listaCat = [];
  for (const cat in porCategoria) {
    listaCat.push({ esquerda: cat, direita: porCategoria[cat] + " un." });
  }
  preencherLista("lista-categorias", listaCat, "Nenhum alimento cadastrado.");

  const listaBreves = breves.map(function (item) {
    return { esquerda: item.nome, direita: formatarData(item.validade) };
  });
  preencherLista("lista-proximos", listaBreves, "Nenhum alimento em breve.");

  const listaVencidos = vencidos.map(function (item) {
    return { esquerda: item.nome, direita: formatarData(item.validade) };
  });
  preencherLista("lista-vencidos", listaVencidos, "Nenhum alimento vencido.");
}

atualizarRelatorios();
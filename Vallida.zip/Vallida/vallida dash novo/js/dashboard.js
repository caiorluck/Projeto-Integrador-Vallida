const alertasRecentes = document.getElementById("alertas-recentes");
const UM_DIA = 24 * 60 * 60 * 1000;

function palavraAlimento(quantidade) {
  return quantidade === 1 ? "alimento" : "alimentos";
}

function atualizarAlertaDoDia(totalBreves, totalVencidos) {
  const icone = document.getElementById("alerta-icone");
  const rotulo = document.getElementById("alerta-rotulo-texto");
  let numero = "";
  let complemento = "";
  let apoio = "";
  let tudoCerto = false;

  if (totalBreves > 0) {
    numero = totalBreves + " " + palavraAlimento(totalBreves);
    complemento = totalBreves === 1 ? "precisa ser consumido em breve." : "precisam ser consumidos em breve.";
    apoio = "Vencem nos próximos " + limiteDias() + " dias";
    if (totalVencidos > 0) {
      apoio += " · " + totalVencidos + (totalVencidos === 1 ? " já venceu" : " já venceram");
    }
    apoio += ".";
  } else if (totalVencidos > 0) {
    numero = totalVencidos + " " + palavraAlimento(totalVencidos);
    complemento = totalVencidos === 1 ? "já passou da validade." : "já passaram da validade.";
    apoio = "Confira a lista de alertas para decidir o que fazer.";
  } else {
    numero = "Tudo certo por aqui";
    complemento = "Nenhum alimento perto de vencer.";
    apoio = "Seu estoque está em dia.";
    tudoCerto = true;
  }

  mostrarTexto("alerta-numero", numero);
  mostrarTexto("alerta-complemento", complemento);
  mostrarTexto("alerta-apoio", apoio);
  mostrarTexto("alerta-rotulo-texto", tudoCerto ? "Tudo em dia" : "Atenção do dia");

  if (icone) {
    icone.className = tudoCerto ? "bi bi-check-circle-fill" : "bi bi-exclamation-triangle-fill";
  }
}

function atualizarResumoSemana(alimentos) {
  const agora = Date.now();
  let cadastrados = 0;
  const vencendo = [];
  let vencidos = 0;

  for (const item of alimentos) {
    const criadoEm = Number(item.id);
    if (criadoEm > 1e12 && agora - criadoEm <= 7 * UM_DIA) {
      cadastrados++;
    }

    const dias = diasAteValidade(item.validade);
    if (dias >= 0 && dias <= 7) {
      vencendo.push(item);
    }
    if (dias < 0 && dias >= -7) {
      vencidos++;
    }
  }

  mostrarTexto("semana-cadastrados", cadastrados);
  mostrarTexto("semana-vencendo", vencendo.length);
  mostrarTexto("semana-vencidos", vencidos);
  mostrarTexto("semana-economia", formatarMoeda(somarValores(vencendo)));
}

function atualizarTela() {
  const alimentos = obterAlimentos();
  const breves = [];
  const vencidos = [];

  for (const item of alimentos) {
    const tipo = statusAlimento(item.validade).tipo;
    if (tipo === "breve") breves.push(item);
    if (tipo === "vencido") vencidos.push(item);
  }

  mostrarTexto("total", alimentos.length);
  mostrarTexto("economia", formatarMoeda(somarValores(breves)));
  atualizarAlertaDoDia(breves.length, vencidos.length);
  atualizarResumoSemana(alimentos);

  const alertas = breves.concat(vencidos);
  alertasRecentes.textContent = "";

  if (alertas.length === 0) {
    alertasRecentes.innerHTML = '<div class="vazio">Nenhum alerta por enquanto.</div>';
    return;
  }

  for (const item of alertas.slice(0, 4)) {
    const status = statusAlimento(item.validade);
    const linha = document.createElement("div");
    linha.className = "alerta-linha";
    linha.innerHTML =
      '<span class="ponto ' + status.classe + '"></span>' +
      "<div><b>" + item.nome + "</b><small>" + item.categoria + "</small></div>" +
      "<small>" + formatarData(item.validade) + "</small>" +
      '<span class="etiqueta ' + status.classe + '">' + status.texto + "</span>";
    alertasRecentes.appendChild(linha);
  }
}

atualizarTela();

let tipoAtual = "todos";

const corpo = document.getElementById("tabela-alertas");
const busca = document.getElementById("busca");
const filtroCategoria = document.getElementById("filtro-categoria");
const filtrosTipo = document.querySelectorAll("[data-tipo]");

function listaFiltrada() {
  const texto = busca.value.trim().toLowerCase();
  const todos = obterAlimentos();

  return todos.filter(function (alimento) {
    const status = statusAlimento(alimento.validade);
    const ehAlerta = status.tipo === "vencido" || status.tipo === "breve";
    const bateTipo = tipoAtual === "todos" || status.tipo === tipoAtual;
    const bateNome = alimento.nome.toLowerCase().includes(texto);
    const bateCategoria =
      filtroCategoria.selectedIndex === 0 || alimento.categoria === filtroCategoria.value;

    return ehAlerta && bateTipo && bateNome && bateCategoria;
  });
}

function excluirAlimento(id) {
  if (!confirm("Deseja excluir este alimento?")) {
    return;
  }

  const novaLista = obterAlimentos().filter(function (item) {
    return item.id !== id;
  });

  salvarAlimentos(novaLista);
  atualizarTela();
}

function atualizarTela() {
  const todos = obterAlimentos();
  let vencidos = 0;
  let vencendo = 0;

  for (const item of todos) {
    const tipo = statusAlimento(item.validade).tipo;
    if (tipo === "vencido") vencidos++;
    if (tipo === "breve") vencendo++;
  }

  mostrarTexto("vencidos", vencidos);
  mostrarTexto("vencendo", vencendo);
  mostrarTexto("total", vencidos + vencendo);

  for (const item of filtrosTipo) {
    if (item.getAttribute("data-tipo") === tipoAtual) {
      item.classList.add("ativo");
    } else {
      item.classList.remove("ativo");
    }
  }

  const lista = listaFiltrada();
  corpo.textContent = "";

  if (lista.length === 0) {
    corpo.innerHTML = '<tr><td colspan="6" class="vazio">Nenhum alerta por enquanto.</td></tr>';
    mostrarTexto("resumo-alertas", "Mostrando 0 de " + (vencidos + vencendo) + " alertas");
    return;
  }

  for (const alimento of lista) {
    const dias = diasAteValidade(alimento.validade);
    const status = statusAlimento(alimento.validade);
    const tr = document.createElement("tr");

    tr.innerHTML =
      "<td><b>" + alimento.nome + "</b> <small>(" + alimento.quantidade + " " + alimento.unidade + ")</small></td>" +
      "<td>" + alimento.categoria + "</td>" +
      "<td>" + formatarData(alimento.validade) + "</td>" +
      "<td>" + (dias < 0 ? "-" : dias) + "</td>" +
      '<td><span class="etiqueta ' + status.classe + '">' + status.texto + "</span></td>" +
      '<td><button type="button" class="acao excluir" aria-label="Excluir"><i class="bi bi-trash"></i></button></td>';

    tr.querySelector(".excluir").addEventListener("click", function () {
      excluirAlimento(alimento.id);
    });

    corpo.appendChild(tr);
  }

  mostrarTexto("resumo-alertas", "Mostrando " + lista.length + " de " + (vencidos + vencendo) + " alertas");
}

for (const item of filtrosTipo) {
  item.addEventListener("click", function (evento) {
    evento.preventDefault();
    tipoAtual = item.getAttribute("data-tipo");
    atualizarTela();
  });
}

busca.addEventListener("input", atualizarTela);
filtroCategoria.addEventListener("change", atualizarTela);

const btnLimpar = document.getElementById("limpar-filtros");
if (btnLimpar) {
  btnLimpar.addEventListener("click", function (evento) {
    evento.preventDefault();
    tipoAtual = "todos";
    busca.value = "";
    filtroCategoria.selectedIndex = 0;
    atualizarTela();
  });
}

atualizarTela();
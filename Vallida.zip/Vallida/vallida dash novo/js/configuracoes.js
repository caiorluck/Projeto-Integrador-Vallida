const formConta = document.getElementById("conta");
const nome = document.getElementById("nome-usuario");
const email = document.getElementById("email-usuario");
const dias = document.getElementById("dias-alerta");
const mensagem = document.getElementById("mensagem-config");

const nomeSalvo = localStorage.getItem(CHAVES.nome);
if (nomeSalvo !== null && nome) {
  nome.value = nomeSalvo;
}

const emailSalvo = localStorage.getItem("vallida_email");
if (emailSalvo !== null && email) {
  email.value = emailSalvo;
}

if (dias) {
  for (const opcao of dias.options) {
    opcao.value = parseInt(opcao.text, 10);
  }
  dias.value = String(limiteDias());

  dias.addEventListener("change", function () {
    localStorage.setItem(CHAVES.dias, dias.value);
  });
}

if (formConta) {
  formConta.addEventListener("submit", function (evento) {
    evento.preventDefault();

    const nomeLimpo = nome ? nome.value.trim() : "";
    const emailLimpo = email ? email.value.trim() : "";

    localStorage.setItem(CHAVES.nome, nomeLimpo);
    localStorage.setItem("vallida_email", emailLimpo);

    for (const el of document.querySelectorAll("[data-nome-usuario]")) {
      el.textContent = nomeLimpo || "Usuário";
    }

    if (mensagem) {
      mensagem.className = "mensagem sucesso";
      mensagem.textContent = "Configurações salvas.";
    }
  });
}

const interruptorAnimacoes = document.querySelector('[data-preferencia="animacoes"]');
if (interruptorAnimacoes) {
  const animacoesAtivas = localStorage.getItem("vallida_animacoes") !== "nao";
  interruptorAnimacoes.checked = animacoesAtivas;
  if (!animacoesAtivas) {
    document.body.classList.add("sem-animacoes");
  }

  interruptorAnimacoes.addEventListener("change", function () {
    const ligada = interruptorAnimacoes.checked;
    localStorage.setItem("vallida_animacoes", ligada ? "sim" : "nao");
    document.body.classList.toggle("sem-animacoes", !ligada);
  });
}

const interruptorEscuro = document.querySelector('[data-preferencia="escuro"]');
if (interruptorEscuro) {
  interruptorEscuro.checked = localStorage.getItem("vallida_tema") === "escuro";

  interruptorEscuro.addEventListener("change", function () {
    const escuro = interruptorEscuro.checked;
    localStorage.setItem("vallida_tema", escuro ? "escuro" : "claro");

    if (escuro) {
      document.documentElement.setAttribute("data-tema", "escuro");
    } else {
      document.documentElement.removeAttribute("data-tema");
    }
  });
}

const secoes = {
  conta: ["conta", "preferencias"],
  notificacoes: ["notificacoes"],
  aparencia: ["aparencia"],
  "alimentos-configuracoes": ["alimentos-configuracoes"],
  privacidade: ["privacidade"]
};

function mostrarSecao(nomeSecao) {
  if (!secoes[nomeSecao]) return;

  for (const cartao of document.querySelectorAll(".conteudo-configuracoes > .cartao")) {
    cartao.hidden = !secoes[nomeSecao].includes(cartao.id);
  }

  for (const link of document.querySelectorAll(".menu-configuracoes a")) {
    link.classList.toggle("ativo", link.getAttribute("href") === "#" + nomeSecao);
  }
}

for (const link of document.querySelectorAll(".menu-configuracoes a")) {
  link.addEventListener("click", function (evento) {
    evento.preventDefault();
    mostrarSecao(link.getAttribute("href").slice(1));
  });
}

mostrarSecao("conta");

const btnLimpar = document.getElementById("limpar-dados");
if (btnLimpar) {
  btnLimpar.addEventListener("click", function () {
    if (confirm("Isso apagará todos os alimentos cadastrados. Deseja continuar?")) {
      localStorage.removeItem(CHAVES.alimentos);
      alert("Alimentos removidos.");
    }
  });
}

const btnExcluir = document.getElementById("excluir-conta");
if (btnExcluir) {
  btnExcluir.addEventListener("click", function () {
    if (confirm("Isso apagará sua conta e todos os dados deste navegador. Deseja continuar?")) {
      for (const chave in CHAVES) {
        localStorage.removeItem(CHAVES[chave]);
      }
      localStorage.removeItem("vallida_email");
      localStorage.removeItem("vallida_animacoes");
      localStorage.removeItem("vallida_tema");
      window.location.href = "login.html";
    }
  });
}
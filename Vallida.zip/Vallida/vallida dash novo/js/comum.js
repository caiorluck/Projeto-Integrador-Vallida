const CHAVES = {
  alimentos: "vallida_alimentos",
  dias: "vallida_dias_alerta",
  nome: "vallida_nome",
  logado: "vallida_logado"
};

if (localStorage.getItem(CHAVES.logado) !== "sim") {
  window.location.href = "login.html";
}

function lerLista(chave) {
  const dados = localStorage.getItem(chave);
  if (dados === null) {
    return [];
  }

  try {
    const lista = JSON.parse(dados);
    return Array.isArray(lista) ? lista : [];
  } catch (erro) {
    return [];
  }
}

function obterAlimentos() {
  return lerLista(CHAVES.alimentos);
}

function salvarAlimentos(lista) {
  localStorage.setItem(CHAVES.alimentos, JSON.stringify(lista));
}

function limiteDias() {
  const limite = localStorage.getItem(CHAVES.dias);
  return limite === null ? 5 : Number(limite);
}

function diasAteValidade(dataValidade) {
  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0);

  const validade = new Date(dataValidade + "T00:00:00");
  return Math.round((validade - hoje) / (1000 * 60 * 60 * 24));
}

function statusAlimento(dataValidade) {
  const dias = diasAteValidade(dataValidade);

  if (dias < 0) {
    return { tipo: "vencido", texto: "Vencido", classe: "vermelho" };
  }
  if (dias <= limiteDias()) {
    return { tipo: "breve", texto: "Vencendo em breve", classe: "amarelo" };
  }
  return { tipo: "ok", texto: "Dentro do prazo", classe: "verde" };
}

function formatarData(data) {
  if (!data) {
    return "-";
  }
  const partes = data.split("-");
  return partes[2] + "/" + partes[1] + "/" + partes[0];
}

function formatarMoeda(valor) {
  const numero = Number(valor);
  const seguro = isNaN(numero) ? 0 : numero;
  return seguro.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function somarValores(lista) {
  let total = 0;
  for (const item of lista) {
    const valor = Number(item.valor);
    if (!isNaN(valor)) {
      total += valor;
    }
  }
  return total;
}

function mostrarTexto(id, texto) {
  const elemento = document.getElementById(id);
  if (elemento) {
    elemento.textContent = texto;
  }
}

let nomeUsuario = localStorage.getItem(CHAVES.nome);
if (!nomeUsuario) {
  nomeUsuario = "Usuário";
}

for (const el of document.querySelectorAll("[data-nome-usuario]")) {
  el.textContent = nomeUsuario;
}

for (const el of document.querySelectorAll("[data-hoje]")) {
  el.textContent = new Date().toLocaleDateString("pt-BR", {
    day: "numeric",
    month: "long",
    year: "numeric"
  });
}

const botaoUsuario = document.querySelector(".usuario");
if (botaoUsuario) {
  const menuUsuario = botaoUsuario.querySelector(".menu-usuario");
  botaoUsuario.addEventListener("click", function () {
    menuUsuario.classList.toggle("aberto");
  });
  document.addEventListener("click", function (evento) {
    if (!botaoUsuario.contains(evento.target)) {
      menuUsuario.classList.remove("aberto");
    }
  });
}

for (const btn of document.querySelectorAll("[data-sair]")) {
  btn.addEventListener("click", function () {
    localStorage.removeItem(CHAVES.logado);
  });
}
const corpo = document.getElementById("tabela-alimentos");
const busca = document.getElementById("busca");
const filtroCategoria = document.getElementById("filtro-categoria");
const selects = document.querySelectorAll(".barra select");
const filtroStatus = selects[1];

const TIPOS_STATUS = ["todos", "ok", "breve", "vencido"];

function listaFiltrada() {
  const texto = busca.value.trim().toLowerCase();
  const tipo = TIPOS_STATUS[filtroStatus.selectedIndex];
  const todos = obterAlimentos();

  return todos.filter(function (alimento) {
    const bateNome = alimento.nome.toLowerCase().includes(texto);
    const bateCategoria =
      filtroCategoria.selectedIndex === 0 || alimento.categoria === filtroCategoria.value;
    const bateStatus = tipo === "todos" || statusAlimento(alimento.validade).tipo === tipo;

    return bateNome && bateCategoria && bateStatus;
  });
}

function excluirAlimento(id) {
  const confirmou = confirm("Deseja excluir este alimento?");
  if (!confirmou) {
    return;
  }

  const novaLista = obterAlimentos().filter(function (item) {
    return item.id !== id;
  });

  salvarAlimentos(novaLista);
  atualizarTela();
}

function atualizarTela() {
  const todos = obterAlimentos();
  let vencendo = 0;
  let vencidos = 0;

  for (const item of todos) {
    const tipo = statusAlimento(item.validade).tipo;
    if (tipo === "breve") vencendo++;
    if (tipo === "vencido") vencidos++;
  }

  mostrarTexto("total", todos.length);
  mostrarTexto("vencendo", vencendo);
  mostrarTexto("vencidos", vencidos);
  mostrarTexto("texto-limite", limiteDias());

  const lista = listaFiltrada();
  corpo.textContent = "";

  if (lista.length === 0) {
    corpo.innerHTML = '<tr><td colspan="6" class="vazio">Nenhum alimento encontrado.</td></tr>';
    mostrarTexto("resumo-paginacao", "Mostrando 0 de 0 alimentos");
    return;
  }

  for (const alimento of lista) {
    const status = statusAlimento(alimento.validade);
    const tr = document.createElement("tr");

    tr.innerHTML =
      "<td><b>" + alimento.nome + "</b></td>" +
      "<td>" + alimento.categoria + "</td>" +
      "<td>" + formatarData(alimento.validade) + "</td>" +
      '<td><span class="etiqueta ' + status.classe + '">' + status.texto + "</span></td>" +
      "<td>" + formatarMoeda(alimento.valor) + " <small>(" + alimento.quantidade + " " + alimento.unidade + ")</small></td>" +
      '<td><button type="button" class="acao excluir" aria-label="Excluir" data-id="' + alimento.id + '"><i class="bi bi-trash"></i></button></td>';

    tr.querySelector(".excluir").addEventListener("click", function () {
      excluirAlimento(alimento.id);
    });

    corpo.appendChild(tr);
  }

  mostrarTexto("resumo-paginacao", "Mostrando " + lista.length + " de " + todos.length + " alimentos");
}

busca.addEventListener("input", atualizarTela);
filtroCategoria.addEventListener("change", atualizarTela);
filtroStatus.addEventListener("change", atualizarTela);

atualizarTela();
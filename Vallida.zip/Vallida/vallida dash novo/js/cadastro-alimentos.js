const formulario = document.getElementById("formulario-alimento");
const mensagem = document.getElementById("mensagem");
const observacoes = document.getElementById("observacoes");
const contador = document.getElementById("contador");

observacoes.addEventListener("input", function () {
  contador.textContent = observacoes.value.length + "/200";
});

formulario.addEventListener("submit", function (evento) {
  evento.preventDefault();

  const nome = document.getElementById("nome").value.trim();
  const categoria = document.getElementById("categoria").value;
  const quantidade = Number(document.getElementById("quantidade").value);
  const unidade = document.getElementById("unidade").value;
  const validade = document.getElementById("validade").value;
  const valorTexto = document.getElementById("valor").value.trim().replace(",", ".");
  const valor = Number(valorTexto);

  if (nome === "") {
    mensagem.className = "mensagem erro";
    mensagem.textContent = "Digite o nome do alimento.";
    return;
  }

  if (valorTexto === "" || isNaN(valor) || valor < 0) {
    mensagem.className = "mensagem erro";
    mensagem.textContent = "Digite um valor válido. Exemplo: 5,90";
    return;
  }

  const alimentos = obterAlimentos();
  alimentos.push({
    id: Date.now(),
    nome: nome,
    categoria: categoria,
    quantidade: quantidade,
    unidade: unidade,
    validade: validade,
    valor: valor,
    observacoes: observacoes.value.trim()
  });

  salvarAlimentos(alimentos);

  formulario.reset();
  contador.textContent = "0/200";
  mensagem.className = "mensagem sucesso";
  mensagem.textContent = "Alimento cadastrado com sucesso!";
});
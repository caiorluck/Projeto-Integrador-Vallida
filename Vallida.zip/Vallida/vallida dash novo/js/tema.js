(function () {
  let escuro = false;

  try {
    escuro = localStorage.getItem("vallida_tema") === "escuro";
  } catch (erro) {
    escuro = false;
  }

  if (escuro) {
    document.documentElement.setAttribute("data-tema", "escuro");
  }
})();

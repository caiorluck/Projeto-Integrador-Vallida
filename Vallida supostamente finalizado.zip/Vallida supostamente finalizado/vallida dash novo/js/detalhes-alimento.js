let idSelecionado = null; // qual alimento está aberto agora

let opcoesCategoria = "";
for (let i = 0; i < CATEGORIAS.length; i++) {
  opcoesCategoria += "<option>" + CATEGORIAS[i] + "</option>";
}

let opcoesUnidade = "";
for (let i = 0; i < UNIDADES.length; i++) {
  opcoesUnidade += "<option>" + UNIDADES[i] + "</option>";
}

let html = "";
html += '<div class="modal" id="modal-alimento" role="dialog" aria-modal="true" aria-labelledby="modal-titulo">';
html += '<div class="modal-caixa">';
html += '<div class="modal-topo"><h2 id="modal-titulo"></h2>';
html += '<button type="button" class="acao" id="fechar-modal" aria-label="Fechar"><i class="bi bi-x-lg"></i></button></div>';

html += '<div id="modo-detalhes">';
html += '<div class="detalhes">';
html += '<div><span>Quantidade</span><b id="det-quantidade"></b></div>';
html += '<div><span>Categoria</span><b id="det-categoria"></b></div>';
html += '<div><span>Validade</span><b id="det-validade"></b></div>';
html += '<div><span>Valor estimado</span><b id="det-valor"></b></div>';
html += '<div><span>Status</span><div id="det-status"></div></div>';
html += '<div class="inteira"><span>Observações</span><b id="det-observacoes"></b></div>';
html += "</div>";
html += '<div class="acoes">';
html += '<button type="button" class="botao perigo" id="excluir-alimento"><i class="bi bi-trash"></i> Excluir</button>';
html += '<button type="button" class="botao" id="editar-alimento"><i class="bi bi-pencil"></i> Editar</button>';
html += "</div>";
html += "</div>";

html += '<form class="formulario" id="formulario-editar" hidden>';
html += '<div><label for="editar-nome">Nome</label><input class="campo" id="editar-nome" required></div>';
html += '<div><label for="editar-categoria">Categoria</label><select class="campo" id="editar-categoria">' + opcoesCategoria + "</select></div>";
html += '<div><label for="editar-quantidade">Quantidade</label><input class="campo" id="editar-quantidade" type="number" min="0.01" step="any" required></div>';
html += '<div><label for="editar-unidade">Unidade</label><select class="campo" id="editar-unidade">' + opcoesUnidade + "</select></div>";
html += '<div><label for="editar-validade">Data de validade</label><input class="campo" id="editar-validade" type="date" required></div>';
html += '<div><label for="editar-valor">Valor estimado (R$)</label><input class="campo" id="editar-valor" inputmode="decimal" required></div>';
html += '<div style="grid-column:1/-1"><label for="editar-observacoes">Observações</label><textarea class="campo" id="editar-observacoes" rows="3" maxlength="200"></textarea></div>';
html += '<div class="acoes" style="grid-column:1/-1">';
html += '<button type="button" class="botao contorno" id="cancelar-edicao">Cancelar</button>';
html += '<button type="submit" class="botao">Salvar</button>';
html += "</div>";
html += "</form>";

html += "</div>";
html += "</div>";

document.body.insertAdjacentHTML("beforeend", html);

const modal = document.getElementById("modal-alimento");
const formularioEditar = document.getElementById("formulario-editar");
const modoDetalhes = document.getElementById("modo-detalhes");

function abrirDetalhes(id) {
  const alimento = buscarAlimento(id);

  if (alimento === null) {
    return;
  }

  idSelecionado = id;

  mostrarTexto("modal-titulo", alimento.nome);
  mostrarTexto("det-quantidade", alimento.quantidade + " " + alimento.unidade);
  mostrarTexto("det-categoria", alimento.categoria);
  mostrarTexto("det-validade", formatarData(alimento.validade));
  mostrarTexto("det-valor", formatarMoeda(alimento.valor));

  const campoStatus = document.getElementById("det-status");
  campoStatus.textContent = "";
  campoStatus.appendChild(criarEtiqueta(statusAlimento(alimento.validade)));

  if (!alimento.observacoes) {
    mostrarTexto("det-observacoes", "Nenhuma observação cadastrada.");
  } else {
    mostrarTexto("det-observacoes", alimento.observacoes);
  }

  modoDetalhes.hidden = false;
  formularioEditar.hidden = true;
  modal.classList.add("aberto");
}

function fecharModal() {
  modal.classList.remove("aberto");
}

function iniciarEdicao() {
  const alimento = buscarAlimento(idSelecionado);

  if (alimento === null) {
    return;
  }

  document.getElementById("editar-nome").value = alimento.nome;
  document.getElementById("editar-categoria").value = alimento.categoria;
  document.getElementById("editar-quantidade").value = alimento.quantidade;
  document.getElementById("editar-unidade").value = alimento.unidade;
  document.getElementById("editar-validade").value = alimento.validade;
  document.getElementById("editar-observacoes").value = alimento.observacoes || "";

  let valorTexto = "";
  if (alimento.valor !== undefined) {
    valorTexto = String(alimento.valor).replace(".", ",");
  }
  document.getElementById("editar-valor").value = valorTexto;

  mostrarTexto("modal-titulo", "Editar alimento");
  modoDetalhes.hidden = true;
  formularioEditar.hidden = false;
}

function editarAlimento(id) {
  abrirDetalhes(id);
  iniciarEdicao();
}

function salvarEdicao(evento) {
  evento.preventDefault();

  const valor = Number(document.getElementById("editar-valor").value.replace(",", "."));

  if (isNaN(valor) || valor < 0) {
    alert("Digite um valor válido. Exemplo: 5,90");
    return;
  }

  const lista = obterAlimentos();

  for (let i = 0; i < lista.length; i++) {
    if (lista[i].id === idSelecionado) {
      lista[i].nome = document.getElementById("editar-nome").value.trim();
      lista[i].categoria = document.getElementById("editar-categoria").value;
      lista[i].quantidade = Number(document.getElementById("editar-quantidade").value);
      lista[i].unidade = document.getElementById("editar-unidade").value;
      lista[i].validade = document.getElementById("editar-validade").value;
      lista[i].valor = valor;
      lista[i].observacoes = document.getElementById("editar-observacoes").value.trim();
    }
  }

  salvarAlimentos(lista);
  fecharModal();
  atualizarTela();
}

function excluirAlimento(id) {
  const confirmou = confirm("Deseja realmente excluir este alimento?");

  if (confirmou) {
    removerAlimento(id);
    fecharModal();
    atualizarTela();
  }
}

function resolverAlimento(id) {
  const alimento = buscarAlimento(id);

  if (alimento === null) {
    return;
  }

  const confirmou = confirm("Marcar este alimento como resolvido? Ele sai da lista de alimentos.");

  if (confirmou) {
    alimento.resolvidoEm = hojeISO();
    const resolvidos = obterResolvidos();
    resolvidos.push(alimento);
    salvarResolvidos(resolvidos);

    removerAlimento(id);
    atualizarTela();
  }
}

document.getElementById("fechar-modal").addEventListener("click", fecharModal);
document.getElementById("editar-alimento").addEventListener("click", iniciarEdicao);
formularioEditar.addEventListener("submit", salvarEdicao);

document.getElementById("excluir-alimento").addEventListener("click", function () {
  excluirAlimento(idSelecionado);
});

document.getElementById("cancelar-edicao").addEventListener("click", function () {
  abrirDetalhes(idSelecionado);
});

modal.addEventListener("click", function (evento) {
  if (evento.target === modal) {
    fecharModal();
  }
});

document.addEventListener("keydown", function (evento) {
  if (evento.key === "Escape") {
    fecharModal();
  }
});

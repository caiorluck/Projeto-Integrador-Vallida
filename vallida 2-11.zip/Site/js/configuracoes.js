
const nome = document.getElementById("nome-usuario");
const email = document.getElementById("email-usuario");
const dias = document.getElementById("dias-alerta");
const mensagem = document.getElementById("mensagem-config");


nome.value = localStorage.getItem(CHAVES.nome) || "";
email.value = localStorage.getItem(CHAVES.email) || "";
[...dias.options].forEach((o) => (o.value = parseInt(o.text)));
dias.value = String(limiteDias());

document.getElementById("conta").addEventListener("submit", function (evento) {
  evento.preventDefault();
  localStorage.setItem(CHAVES.nome, nome.value.trim());
  localStorage.setItem(CHAVES.email, email.value.trim());
  document
    .querySelectorAll("[data-nome-usuario]")
    .forEach((e) => (e.textContent = nome.value.trim() || "Usuário"));
  avisar(mensagem, "sucesso", "Configurações salvas.");
});

dias.addEventListener("change", () => localStorage.setItem(CHAVES.dias, dias.value));

const preferencias = JSON.parse(localStorage.getItem(CHAVES.preferencias) || "{}");
document.querySelectorAll(".interruptor input").forEach(function (interruptor) {
  const chave = interruptor.dataset.preferencia;
  if (chave in preferencias) interruptor.checked = preferencias[chave];
  interruptor.addEventListener("change", function () {
    preferencias[chave] = interruptor.checked;
    localStorage.setItem(CHAVES.preferencias, JSON.stringify(preferencias));
    if (chave === "animacoes") document.body.classList.toggle("sem-animacoes", !interruptor.checked);
  });
});

const secoes = {
  conta: ["conta", "preferencias"],
  notificacoes: ["notificacoes"],
  aparencia: ["aparencia"],
  "alimentos-configuracoes": ["alimentos-configuracoes"],
  privacidade: ["privacidade"],
};
function mostrarSecao(nomeSecao) {
  document.querySelectorAll(".conteudo-configuracoes > .cartao").forEach((c) => {
    c.hidden = !secoes[nomeSecao].includes(c.id);
  });
  document.querySelectorAll(".menu-configuracoes a").forEach((a) => {
    a.classList.toggle("ativo", a.getAttribute("href") === "#" + nomeSecao);
  });
}
document.querySelectorAll(".menu-configuracoes a").forEach((link) =>
  link.addEventListener("click", function (evento) {
    evento.preventDefault();
    mostrarSecao(link.getAttribute("href").slice(1));
  }),
);
mostrarSecao("conta");

// Privacidade
document.getElementById("exportar-dados").addEventListener("click", function () {
  const dados = { alimentos: obterAlimentos(), resolvidos: lerLista(CHAVES.resolvidos) };
  const link = document.createElement("a");
  link.href = URL.createObjectURL(new Blob([JSON.stringify(dados, null, 2)], { type: "application/json" }));
  link.download = "vallida-dados.json";
  link.click();
});
document.getElementById("limpar-dados").addEventListener("click", function () {
  if (confirm("Isso apagará todos os alimentos cadastrados. Deseja continuar?")) {
    localStorage.removeItem(CHAVES.alimentos);
    alert("Alimentos removidos.");
  }
});
document.getElementById("excluir-conta").addEventListener("click", function () {
  if (confirm("Isso apagará sua conta e todos os dados deste navegador. Deseja continuar?")) {
    Object.values(CHAVES).forEach((chave) => localStorage.removeItem(chave));
    window.location.href = "login.html";
  }
});

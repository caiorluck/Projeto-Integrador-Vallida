const POR_PAGINA = 8;
let paginaAtual = 1;

const corpo = document.getElementById("tabela-alimentos");
const busca = document.getElementById("busca");
const filtroCategoria = document.getElementById("filtro-categoria");
const filtroStatus = document.querySelector(".barra select:not(#filtro-categoria)");
const TIPOS_STATUS = ["todos", "ok", "breve", "vencido"]; 

function listaFiltrada() {
  const texto = busca.value.trim().toLowerCase();
  const tipo = TIPOS_STATUS[filtroStatus.selectedIndex];
  return obterAlimentos()
    .filter(
      (a) =>
        a.nome.toLowerCase().includes(texto) &&
        (filtroCategoria.selectedIndex === 0 || a.categoria === filtroCategoria.value) &&
        (tipo === "todos" || statusAlimento(a.validade).tipo === tipo),
    )
    .sort((a, b) => a.validade.localeCompare(b.validade));
}

function desenhar() {
  const todos = obterAlimentos();
  document.getElementById("total").textContent = todos.length;
  document.getElementById("vencendo").textContent = todos.filter(
    (a) => statusAlimento(a.validade).tipo === "breve",
  ).length;
  document.getElementById("vencidos").textContent = todos.filter(
    (a) => statusAlimento(a.validade).tipo === "vencido",
  ).length;
  document.getElementById("texto-limite").textContent = limiteDias();

  const lista = listaFiltrada();
  const totalPaginas = Math.max(1, Math.ceil(lista.length / POR_PAGINA));
  if (paginaAtual > totalPaginas) paginaAtual = totalPaginas;
  const pagina = lista.slice((paginaAtual - 1) * POR_PAGINA, paginaAtual * POR_PAGINA);

  corpo.innerHTML = pagina.length
    ? pagina
        .map((a) => {
          const s = statusAlimento(a.validade);
          return `<tr class="linha-clicavel" data-id="${a.id}" title="Clique para ver os detalhes"><td>${escaparHtml(a.nome)}</td><td>${escaparHtml(a.categoria)}</td><td>${formatarData(a.validade)}</td><td><span class="etiqueta ${s.classe}">${s.texto}</span></td><td>${formatarMoeda(a.valor)} <small>(${a.quantidade} ${escaparHtml(a.unidade)})</small></td><td><button class="acao" data-acao="editar" aria-label="Editar"><i class="bi bi-pencil"></i></button> <button class="acao excluir" data-acao="excluir" aria-label="Excluir"><i class="bi bi-trash"></i></button></td></tr>`;
        })
        .join("")
    : `<tr><td colspan="6" class="vazio">Nenhum alimento encontrado.</td></tr>`;

  document.getElementById("resumo-paginacao").textContent =
    `Mostrando ${pagina.length} de ${lista.length} alimentos`;

  let botoes = `<span data-pagina="${paginaAtual - 1}"><i class="bi bi-chevron-left"></i></span>`;
  for (let p = 1; p <= totalPaginas; p++) {
    botoes += `<span data-pagina="${p}"${p === paginaAtual ? ' class="ativo"' : ""}>${p}</span>`;
  }
  botoes += `<span data-pagina="${paginaAtual + 1}"><i class="bi bi-chevron-right"></i></span>`;
  document.getElementById("paginacao").innerHTML = botoes;
}

document.getElementById("paginacao").addEventListener("click", function (evento) {
  const botao = evento.target.closest("[data-pagina]");
  if (!botao) return;
  paginaAtual = Number(botao.dataset.pagina) || 1;
  desenhar();
});

[busca, filtroCategoria, filtroStatus].forEach((campo) => {
  campo.addEventListener(campo === busca ? "input" : "change", function () {
    paginaAtual = 1;
    desenhar();
  });
});
document.addEventListener("alimentos-alterados", desenhar);
desenhar();
